execute as @e[type=armor_stand,nbt={Tags:["pokestop_cobbledstop_spawner"]}] at @s run npcspawn pokestop
execute as @e[type=armor_stand,nbt={Tags:["pokestop_cobbledstop_spawner"]}] at @s run kill @s